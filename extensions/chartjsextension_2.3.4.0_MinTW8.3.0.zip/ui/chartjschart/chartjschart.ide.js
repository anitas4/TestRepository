TW.IDE.Widgets.chartjschart = function () {

	this.widgetIconUrl = function() {
		return  "'../Common/extensions/chartjsextension/ui/chartjschart/default_widget_icon.ide.png'";
	};

	this.widgetProperties = function () {
		return {
			'name': 'chartjschart',
			'description': '',
			'category': ['Common'],
			'supportsAutoResize': true,
			'properties': {
				'chartjschart Property': {
					'baseType': 'STRING',
					'defaultValue': 'chartjschart Property default value',
					'isBindingTarget': true
				},
				'data': {
					'baseType' : 'INFOTABLE',
					'defaultValue' : {},
					'isBindingTarget': true
				},
				'dataJson': {
					'baseType' : 'JSON',
					'defaultValue' : {},
					'isBindingTarget': true
				},
				'uniqueProperty': {
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'defaultValue': '',
                    'baseType': 'STRING',
                },
                'clickedDataSet': {
                    'isBindingSource': true,
                    'defaultValue': '',
                    'baseType': 'STRING',
                },
				'clickedXLabel': {
                    'isBindingSource': true,
                    'defaultValue': '',
                    'baseType': 'STRING',
                },
                'clickedYValue': {
                    'isBindingSource': true,
                    'defaultValue': '',
                    'baseType': 'STRING',
                }
			}
		}
	};

	this.afterSetProperty = function (name, value) {
		var thisWidget = this;
		var refreshHtml = false;
		switch (name) {
			case 'Style':
			case 'chartjschart Property':
				thisWidget.jqElement.find('.chartjschart-property').text(value);
			case 'Alignment':
				refreshHtml = true;
				break;
			default:
				break;
		}
		return refreshHtml;
	};

	this.renderHtml = function () {
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName).
		return 	'<div class="widget-content widget-chartjschart">' +
					'<span class="chartjschart-property">' + this.getProperty('chartjschart Property') + '</span>' +
				'</div>';
	};

	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()

		// get a reference to the value element
		valueElem = this.jqElement.find('.chartjschart-property');
		// update that DOM element based on the property value that the user set
		// in the mashup builder
		valueElem.text(this.getProperty('chartjschart Property'));
	};
	
	this.widgetEvents = function () {
        return {
            'click': {}
        }
    };

};