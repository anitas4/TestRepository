/*global Encoder,TW */

TW.IDE.Widgets.ImageFromBase64 = function () {
    var roundedCorners = true;
    this.widgetProperties = function () {
        return {
            'name': 'ImageFromBase64',
            'description': 'Render an image from the base64 string provided',
            'category': ['Common'],
            'iconImage': 'ImageFromBase64.ide.png',
            'properties': {
                'Width': {
                    'description': 'Width of widget',
                    'baseType': 'NUMBER',
                    'defaultValue': 75
                },
                'Height': {
                    'description': 'Height of widget',
                    'baseType': 'NUMBER',
                    'defaultValue': 30
                },
                'imageData' : {
                	'description': 'Image content as a base64 string',
                	'baseType': 'STRING',
                	'defaultValue': '',
                	'isBindingTarget': true,
                	'isBindingSource': true
                },
                'ImageScaling': {
                    'isVisible': true, 
                    'baseType': 'STRING',
                    'defaultValue' : 'unset',
                    'description': '',
                    'selectOptions' : [
                        { value: 'unset', text: 'unset' },
                		{ value: 'contain', text: 'contain'},
                		{ value: 'cover', text: 'cover' }
                	]
                }
            }
        };
    };
    
    this.widgetIconUrl = function () {
        return  "../Common/extensions/ImageFromBase64/ui/ImageFromBase64/images/ImageFromBase64.ide.png";
    };
    
    this.widgetEvents = function () {
        return {
            'Clicked': { 'warnIfNotBound': true }
        };
    };

    this.afterSetProperty = function (name, value) {
        var result = false;
        switch (name) {
            case 'Label' :
            case 'Style':
            case 'Width':
            case 'Height':
            case 'RoundedCorners':
            case 'HoverStyle':
            case 'IconAlignment':
                result = true;
                break;
            default:
                break;
        }
        return result;
    };


    this.renderHtml = function () {
        html = '<div class="widget-content ImageFromBase64">'
        	 + '</div>';
        return html;
    };
    
    this.widgetServices = function () {
        return {
            'RenderContent': { 'warnIfNotBound': false }
        };
    };

    this.widgetEvents = function () {
        return {};
    };
    
    this.afterRender = function () {
    };
};