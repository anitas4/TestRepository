// Custom Column Type
(function () {
    /**
        Description : entityPicker with entityType as MediaEntities.
        Usage -> gridAdvanced.setColTypes("entityPicker,...");
    **/
    function eXcell_entityPicker(cell) {
        if (cell) {
            this.cell = cell;
            this.grid = this.cell.parentNode.grid;
            this.cellElement = $(cell);
        }
        this.setValue = function (val) {
            this.setCValue(val);
        };
        this.getValue = function () {
            return this.cell.innerHTML;
        };
        this.edit = function () {
            var cellReference = this;
            this.val = this.getValue();
            var value = this.val;
            var imageNameArr = value.split('/');
            var imageName = imageNameArr[imageNameArr.length - 1];
            imageName = imageName.length > 10 ? imageName.substring(0, 6) + '...' : imageName;
            if (imageName !== '') {
                value = '<div class="magic-picker-contents widget-entitypicker" style="width: inherit">' +
                    '<div class="btn-group">' +
                    '<img width="15%" height="15%" src = "' + this.cell.innerHTML + '"/>' +
                    '<span align="center" style="display: inline-block; padding-left:5px;">' + imageName + '</span>' +
                    '<span id="icon-remove" class="remove-entity btn btn-small" style="position:relative; float:right">' +
                    '<i class="icon-remove"></i></span>' +
                    '</div>' +
                    '</div>';
                this.cell.innerHTML = value;

                var element = this.cellElement;
                var removeIcon = element.find('#icon-remove');
                removeIcon.on('click', function (e) {
                    cellReference.val = '';
                    cellReference.attachMagicPicker(cellReference);
                    e.stopPropagation();
                });
            } else {
                cellReference.attachMagicPicker(cellReference);
            }
        };

        this.attachMagicPicker = function (cellReference) {
            var element = cellReference.cellElement;
            element.twMagicPicker({
                allowNew: false,
                entityType: 'MediaEntities',
                entityName: undefined,
                editMode: true,
                restrictToThingTemplates: undefined,
                restrictToThingShapes: undefined,
                placeHolderText: undefined,
                showAdvanced: true,
                useMostRecentlyUsed: true,
                showInspect: false,
                searchTerm: undefined,
                presetAdvancedFilters: { searchDescriptions: true, showSystemObjects: false },
                cellReference: cellReference,
                singleEntityChanged: function (entity) {
                    var path = cellReference._convertImageLink(entity.entityName);
                    cellReference.val = path;
                    setTimeout(function () { // setTimeout to allow twMagicpicker perform other operations
                        cellReference.grid.editStop();
                    }, 100);
                }
            });
            var twInlineSearchEl = element.find('.twInlineSearch');
            twInlineSearchEl.on('click', function (e) {
                e.stopPropagation();
            });
            var twInlineSearchResults = $('body').find('.inline-results');
            twInlineSearchResults.on('click', function (e) {
                e.stopPropagation();
            });
        };
        this._convertImageLink = function (imageLink) {
            var path = '';
            if (imageLink && typeof imageLink === 'string') {
                if (imageLink.length > 0 && imageLink.indexOf('/') === -1) {
                    path = '/Thingworx/MediaEntities/' + encodeURIComponent(imageLink);
                } else {
                    // the full path
                    if (imageLink.indexOf('http') !== 0) {
                        imageLink = window.location.origin + imageLink;
                    }
                    path = XSS.sanitizeHtml(imageLink);
                }
            }
            return path;
        };
        this.detach = function () {
            this.cellElement.twMagicPicker('destroy');
            this.setValue(this.val);
            return true;
        };
    };
    eXcell_entityPicker.prototype = new eXcell;
    window.eXcell_entityPicker = eXcell_entityPicker;


    /**
        Description : editNumber(edn) with XSS encoding.(ednXSS)
        Usage -> gridAdvanced.setColTypes("ednXSS,...");
    **/
    function eXcell_ednXSS(cell) {
        this.base = eXcell_edn;
        this.base(cell);
        this.detach = function () {
            var b = this.obj.value;
            if (_.isString(b)) {
                b = XSS.encodeHTML(b);
            }
            this.setValue(b);
            return this.val != this.getValue();
        }
    }
    eXcell_ednXSS.prototype = new eXcell_edn;
    window.eXcell_ednXSS = eXcell_ednXSS;

    /**
        Description : edit(ed) with html sanitizing.(edHS)
        Usage -> gridAdvanced.setColTypes("edHS,...");
    **/
    function eXcell_edHS(cell) {
        this.base = eXcell_ed;
        this.base(cell);
        this.detach = function () {
            var b = this.obj.value;
            if (_.isString(b)) {
                b = twHtmlUtilities.sanitizeHtml(b);
            }
            this.setValue(b);
            return this.val != this.getValue();
        }
    }
    eXcell_edHS.prototype = new eXcell_ed;
    window.eXcell_edHS = eXcell_edHS;
})();