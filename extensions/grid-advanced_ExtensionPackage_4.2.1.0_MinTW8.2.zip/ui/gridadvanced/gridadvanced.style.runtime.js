gaRequire.require.config({
    baseUrl: '../Common/extensions/grid-advanced_ExtensionPackage/ui/gridadvanced/include'
});

TW.Runtime.Widgets.gridadvanced.getWidgetStyleDict = function() {
    return [
        {
            class:  '.widget-gridadvanced',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        'border-color':    '${gridadv-bordercolor}',
                        'border-width':    '${gridadv-borderthickness}',
                        'border-style':    'solid',
                    }
                }
            ]
        },
        {
            class:  '.objbox',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:        '${gridBackgroundColor}'
                    }
                }
            ]
        },
        {
            class:  '.xhdr table tbody tr td',
            states:
            [
                {
                    state:  '',
                    styles:
                    {   
                        'font-family':      '${gridadv-header-label-fontfamily}',
                        'font-size':        '${gridadv-header-label-fontsize}',
                        'text-transform':   '${gridadv-header-label-fontstyle}',
                        'font-weight':      '${gridadv-header-label-fontweight}',
                        color:              '${gridadv-header-label-fontcolor}',
                        background :        '${gridadv-header-backgroundcolor}',
                        'font-style':       '${font-style-cond(gridadv-header-label-fontstyle)}',
                        'text-decoration':  '${text-decoration-cond(gridadv-header-label-fontstyle)}',
                        'border-color':    '${gridadv-header-divider-color}',
                        'border-width':    '${gridadv-header-divider-thickness}',
                        'border-style':    '${gridadv-header-divider-style}'
                    }
                }
            ]
        },
        {
            class:  '.xhdr',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background :        '${gridadv-header-backgroundcolor}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table.obj tbody tr td ',
            states:
            [
                {
                    state:  '',
                    styles: {
                        color:                          '${gridadv-cell-text-fontcolor}',
                        background:                     '${gridadv-cell-backgroundcolor}',
                        filter:                         'none',
                        'text-align':                   '${gridadv-cell-text-text-alignment}',
                        'font-weight':                  '${gridadv-cell-text-fontweight}',
                        'font-style':                   '${font-style-cond(gridadv-cell-text-fontstyle)}',
                        'text-decoration':              '${text-decoration-cond(gridadv-cell-text-fontstyle)}',
                        'font-size':                    '${gridadv-cell-text-fontsize}',
                        'font-family':                  '${gridadv-cell-text-fontfamily}',
                        'border-width':                 '${gridadv-cell-borderthickness}',
                        'border-color':                 '${gridadv-cell-bordercolor}',
                        'border-style':                 '${gridadv-cell-border-style}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr.ev_material',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:        '${gridadv-row-backgroundcolor}',
                        'border-color':    '${rowInteriorLineColor}',
                        'border-width':    '${rowInteriorLineThickness}',
                        'border-style':    '${rowInteriorLineStyle}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr.odd_material',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:        '${if(gridadv-row-backgroundcolor-usealternating, gridadv-row-backgroundcolor-alt, gridadv-row-backgroundcolor)}',
                        'border-color':    '${alRowInteriorLineColor}',
                        'border-width':    '${alRowInteriorLineThickness}',
                        'border-style':    '${alRowInteriorLineStyle}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr.ev_material td.grid_hover',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:         '${gridadv-row-backgroundcolor-hover}',
                        filter:             'none',
                        color:              '${gridadv-cell-text-fontcolor-hover}',
                        'text-align':       '${gridadv-cell-text-text-alignment-hover}',
                        'font-weight':      '${gridadv-cell-text-fontweight-hover}',
                        'font-style':       '${font-style-cond(gridadv-cell-text-fontstyle-hover)}',
                        'text-decoration':  '${text-decoration-cond(gridadv-cell-text-fontstyle-hover)}',
                        'font-size':        '${gridadv-cell-text-fontsize-hover}',
                        'font-family':      '${gridadv-cell-text-fontfamily-hover}',
                        'border-width':     '${gridadv-cell-borderthickness-hover}',
                        'border-color':     '${gridadv-cell-bordercolor-hover}',
                        'border-style':     '${gridadv-cell-border-style-hover}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr.odd_material td.grid_hover',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:         '${gridadv-row-backgroundcolor-alt-hover}',
                        filter:             'none',
                        color:              '${gridadv-cell-text-fontcolor-hover}',
                        'text-align':       '${gridadv-cell-text-text-alignment-hover}',
                        'font-weight':      '${gridadv-cell-text-fontweight-hover}',
                        'font-style':       '${font-style-cond(gridadv-cell-text-fontstyle-hover)}',
                        'text-decoration':  '${text-decoration-cond(gridadv-cell-text-fontstyle-hover)}',
                        'font-size':        '${gridadv-cell-text-fontsize-hover}',
                        'font-family':      '${gridadv-cell-text-fontfamily-hover}',
                        'border-width':     '${gridadv-cell-borderthickness-hover}',
                        'border-color':     '${gridadv-cell-bordercolor-hover}',
                        'border-style':     '${gridadv-cell-border-style-hover}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr.odd_material.rowselected td',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:         '${gridadv-row-backgroundcolor-alt-selected}',
                        filter:                         'none',
                        color:                          '${gridadv-cell-text-fontcolor-selected}',
                        'text-align':                   '${gridadv-cell-text-text-alignment-selected}',
                        'font-weight':      '${gridadv-cell-text-fontweight-selected}',
                        'font-style':                   '${font-style-cond(gridadv-cell-text-fontstyle-selected)}',
                        'text-decoration':              '${text-decoration-cond(gridadv-cell-text-fontstyle-selected)}',
                        'font-size':                    '${gridadv-cell-text-fontsize-selected}',
                        'font-family':                  '${gridadv-cell-text-fontfamily-selected}',
                        'border-width':                 '${gridadv-cell-borderthickness-selected}',
                        'border-color':                 '${gridadv-cell-bordercolor-selected}',
                        'border-style':                 '${gridadv-cell-border-style-selected}'
                    }
                }
            ]
        },
        {
            class:  '.objbox table tbody tr.ev_material.rowselected td',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:         '${gridadv-row-backgroundcolor-selected}',
			            filter:                         'none',
                        color:                          '${gridadv-cell-text-fontcolor-selected}',
                        'text-align':                   '${gridadv-cell-text-text-alignment-selected}',
                        'font-weight':      '${gridadv-cell-text-fontweight-selected}',
                        'font-style':                   '${font-style-cond(gridadv-cell-text-fontstyle-selected)}',
                        'text-decoration':              '${text-decoration-cond(gridadv-cell-text-fontstyle-selected)}',
                        'font-size':                    '${gridadv-cell-text-fontsize-selected}',
                        'font-family':                  '${gridadv-cell-text-fontfamily-selected}',
                        'border-width':                 '${gridadv-cell-borderthickness-selected}',
                        'border-color':                 '${gridadv-cell-bordercolor-selected}',
                        'border-style':                 '${gridadv-cell-border-style-selected}'
                    }
                }
            ]
        },
        {
            class:  '.top-container',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:         '${toolbar-backgroundcolor}',
                        filter:             'none',
                        'border-color':     '${toolbar-bordercolor}',
                        'border-style':     'solid',
                        'border-width':     '${toolbar-borderthickness}'
                    }
                }
            ]
        },
        {
            class:  '.bottom-container',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:         '${toolbar-backgroundcolor}',
                        filter:             'none',
                        'border-color':     '${toolbar-bordercolor}',
                        'border-style':     'solid',
                        'border-width':     '${toolbar-borderthickness}'
                    }
                }
            ]
        },
        /*{
            class:  '#tiptip_content',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        background:         '${tooltip-backgroundcolor}',
                        filter:             'none',
                        'border-color':     '${tooltip-bordercolor}',
                        'border-width':     '1px',
                        'border-style':     'solid',
                        color:              '${tooltip-text-color}',
                        'font-weight':      'normal',
                        'font-style':       'normal;',
                        'text-decoration':  'none',
                        'font-size':        '11px'
                    }
                }
            ]
        },*/
        {
            class:  '.toolbar-search-theming div.dhx_toolbar_btn.dhxtoolbar_btn_def input.dhxtoolbar_input',
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        color:              '${textfield-field-text-color}',
                        background:         '${textfield-field-backgroundcolor}',
                        filter:             'none',
                        'font-family':      '${textfield-field-fontfamily}',
                        'font-size':        '${textfield-field-fontsize}',
                        'font-style':       '${font-style-cond(textfield-field-fontstyle)}',
                        'text-decoration':  '${text-decoration-cond(textfield-field-fontstyle)}',
                        'font-weight':      '${textfield-field-fontweight}',
                        'line-height':      '${searchFieldLineSpacing}',
                        'letter-spacing':   '${textfield-field-letterspacing}',
                        'text-align':       '${textfield-field-alignment}',
                        'border-color':     '${textfield-field-bordercolor}',
                        'border-width':     '${textfield-field-borderthickness}',
                        'border-style':     '${textfield-field-border-style}',
                        position:           'relative',
                        margin:             '0 4px',
                        padding:            '2px 4px 3px 4px',
                        direction:          'ltr',
                        outline:            'none'
                    }
                },
                {
                    state:  'hover',
                    styles:
                    {
                        color:              '${textfield-field-text-color-hover}',
                        background:         '${textfield-field-backgroundcolor-hover}',
                        filter:             'none',
                        'font-family':      '${textfield-field-fontfamily-hover}',
                        'font-size':        '${textfield-field-fontsize-hover}',
                        'font-style':       '${font-style-cond(textfield-field-fontstyle-hover)}',
                        'text-decoration':  '${text-decoration-cond(textfield-field-fontstyle-hover)}',
                        'font-weight':      '${textfield-field-fontweight-hover}',
                        'line-height':      '${hoverSearchFieldLineSpacing}',
                        'letter-spacing':   '${textfield-field-letterspacing}',
                        'text-align':       '${textfield-field-alignment}',
                        'border-color':     '${textfield-field-bordercolor-hover}',
                        'border-width':     '${textfield-field-borderthickness-hover}',
                        'border-style':     '${textfield-field-border-style}',
                        position:           'relative',
                        margin:             '0 4px',
                        padding:            '2px 4px 3px 4px',
                        direction:          'ltr',
                        outline:            'none'
                    }
                },
                {
                    state:  'active',
                    styles:
                    {
                        color:              '${textfield-field-text-color-pressed}',
                        background:         '${textfield-field-backgroundcolor-pressed}',
                        filter:             'none',
                        'font-family':      '${textfield-field-fontfamily-pressed}',
                        'font-size':        '${textfield-field-fontsize-pressed}',
                        'font-style':       '${font-style-cond(textfield-field-fontstyle-pressed)}',
                        'text-decoration':  '${text-decoration-cond(textfield-field-fontstyle-pressed)}',
                        'font-weight':      '${textfield-field-fontweight-pressed}',
                        'line-height':      '${pressedSearchFieldLineSpacing}',
                        'letter-spacing':   '${textfield-field-letterspacing}',
                        'text-align':       '${textfield-field-alignment}',
                        'border-color':     '${textfield-field-bordercolor-pressed}',
                        'border-width':     '${textfield-field-borderthickness-pressed}',
                        'border-style':     '${textfield-field-border-style}',
                        position:           'relative',
                        margin:             '0 4px',
                        padding:            '2px 4px 3px 4px',
                        direction:          'ltr',
                        outline:            'none'
                    }
                },
                {
                    state:  'disabled',
                    styles:
                    {
                        color:              '${textfield-field-text-color-disabled}',
                        background:         '${textfield-field-backgroundcolor-disabled}',
                        filter:             'none',
                        'font-family':      '${textfield-field-fontfamily-disabled}',
                        'font-size':        '${textfield-field-fontsize-disabled}',
                        'font-style':       '${font-style-cond(textfield-field-fontstyle-disabled)}',
                        'text-decoration':  '${text-decoration-cond(textfield-field-fontstyle-disabled)}',
                        'font-weight':      '${textfield-field-fontweight-disabled}',
                        'line-height':      '${disabledSearchFieldLineSpacing}',
                        'letter-spacing':   '${textfield-field-letterspacing}',
                        'text-align':       '${textfield-field-alignment}',
                        'border-color':     '${textfield-field-bordercolor-disabled}',
                        'border-width':     '${textfield-field-borderthickness-disabled}',
                        'border-style':     '${textfield-field-border-style}',
                        position:           'relative',
                        margin:             '0 4px',
                        padding:            '2px 4px 3px 4px',
                        direction:          'ltr',
                        outline:            'none'
                    }
                }
            ]
        },
        {
            class:  '.toolbar-search-theming div.dhx_toolbar_text',//Field Label
            states:
            [
                {
                    state:  '',
                    styles:
                    {
                        color:              '${textfield-text-label-color}',
                        background:         '${label-backgroundcolor}',
                        filter:             'none',
                        'font-family':      '${textfield-text-label-fontfamily}',
                        'font-size':        '${textfield-text-label-fontsize}',
                        'font-style':       '${font-style-cond(textfield-text-label-fontstyle)}',
                        'text-decoration':  '${text-decoration-cond(textfield-text-label-fontstyle)}',
                        'font-weight':      '${textfield-text-label-fontweight}',
                        'line-height':      '32px',
                        'letter-spacing':   '${label-letterspacing}',
                        'text-align':       '${label-alignment}',
                        'border-color':     '${label-bordercolor}',
                        'border-width':     '${label-borderthickness}',
                        'border-style':     '${label-border-style}'
                    }
                },
                {
                    state:  'disabled',
                    styles:
                    {
                        color:              '${disabledSearchLabelFontColor}',
                        background:         '${disabledSearchLabelBackgroundColor}',
                        filter:             'none',
                        'font-family':      '${disabledSearchLabelFontFamily}',
                        'font-size':        '${disabledSearchLabelFontSize}',
                        'font-style':       '${font-style-cond(disabledSearchLabelFontStyle)}',
                        'text-decoration':  '${text-decoration-cond(disabledSearchLabelFontStyle)}',
                        'font-weight':      '${disabledSearchLabelFontWeight}',
                        'line-height':      '${disabledSearchLabelLineSpacing}',
                        'letter-spacing':   '${disabledSearchLabelLetterSpacing}',
                        'text-align':       '${disabledSearchLabelTextAlignment}',
                        'border-color':     '${disabledSearchLabelBorderColor}',
                        'border-width':     '${disabledSearchLabelBorderWidth}',
                        'border-style':     '${disabledSearchLabelBorderStyle}'
                    }
                }
            ]
        },
        //Button Active
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_def',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-backgroundcolor}',
                        'border-color':                 '${button-transparent-bordercolor}',
                        'border-width':                 '${button-transparent-borderthickness}',
                        'border-style':                 '${button-transparent-border-style}',
                        'border-radius':                '${button-transparent-radius}',
                        width:                          '${button-transparent-width}',
                        height:                         '${button-transparent-height}',
                        padding:                        '${button-transparent-padding}',
                        float:                          '${button-transparent-alignment}',
                        'line-height':                  '32px',
                        position:                       'relative',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'user-select':                  'none'
                    }
                }
            ]
        },
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_def div.dhxtoolbar_text',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-text-backgroundcolor}',
                        color:                          '${button-transparent-text-color}',
                        'font-family':                  '${button-transparent-fontfamily}',
                        'font-size':                    '${button-transparent-fontsize}',
                        'font-style':                   '${font-style-cond(button-transparent-fontstyle)}',
                        'text-decoration':              '${text-decoration-cond(button-transparent-fontstyle)}',
                        'font-weight':                  '${button-transparent-fontweight}',
                        'line-height':                  '32px',
                        'letter-spacing':               '${button-transparent-letterspacing}',
                        'text-align':                   '${button-transparent-text-alignment}',
                        'border-color':                 '${buttonActiveLabelBorderColor}',
                        'border-width':                 '${buttonActiveLabelBorderThickness}',
                        'border-style':                 '${buttonActiveLabelBorderStyle}',
                        height:                         '32px',
                        float:                          'left',                        
                        position:                       'relative',
                        margin:                         '0 4px',
                        padding:                        '0px',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'white-space':                  'nowrap'
                    }
                }
            ]
        },
        //Button Hover
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_over',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-backgroundcolor-hover}',
                        'border-color':                 '${button-transparent-bordercolor-hover}',
                        'border-width':                 '${button-transparent-borderthickness-hover}',
                        'border-style':                 '${button-transparent-border-style-hover}',
                        'border-radius':                '${button-transparent-radius-hover}',
                        width:                          '${button-transparent-width}',
                        height:                         '${button-transparent-height}',
                        padding:                        '${button-transparent-padding}',
                        float:                          '${button-transparent-alignment}',
                        'line-height':                  '32px',
                        position:                       'relative',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'user-select':                  'none'
                    }
                }
            ]
        },
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_over div.dhxtoolbar_text',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-text-backgroundcolor-hover}',
                        color:                          '${button-transparent-text-color-hover}',
                        'font-family':                  '${button-transparent-fontfamily-hover}',
                        'font-size':                    '${button-transparent-fontsize-hover}',
                        'font-style':                   '${font-style-cond(button-transparent-fontstyle-hover)}',
                        'text-decoration':              '${text-decoration-cond(button-transparent-fontstyle-hover)}',
                        'font-weight':                  '${button-transparent-fontweight-hover}',
                        'line-height':                  '${buttonHoverLabelLineSpacing}',
                        'letter-spacing':               '${button-transparent-letterspacing}',
                        'text-align':                   '${button-transparent-text-alignment}',
                        'border-color':                 '${buttonHoverLabelBorderColor}',
                        'border-width':                 '${buttonHoverLabelBorderThickness}',
                        'border-style':                 '${buttonHoverLabelBorderStyle}',
                        height:                         '32px',
                        float:                          'left',                        
                        position:                       'relative',
                        margin:                         '0 4px',
                        padding:                        '0px',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'white-space':                  'nowrap'
                    }
                }
            ]
        },
        //Button Selected
        /*
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn ',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${buttonSelectedBackgroundColor}',
                        'border-color':                 '${buttonSelectedBorderColor}',
                        'border-width':                 '${buttonSelectedBorderThickness}',
                        'border-style':                 '${buttonSelectedBorderStyle}',
                        'border-radius':                '${buttonSelectedBorderRadius}',
                        width:                          '${buttonSelectedWidth}',
                        height:                         '${buttonSelectedHeight}',
                        padding:                        '${buttonSelectedPadding}',
                        float:                          '${buttonSelectedAlignment}',
                        'line-height':                  '32px',
                        position:                       'relative',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'user-select':                  'none'
                    }
                }
            ]
        },
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn  div.dhxtoolbar_text',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${buttonSelectedLabelBackgroundColor}',
                        color:                          '${buttonSelectedLabelFontColor}',
                        'font-family':                  '${buttonSelectedLabelFontFamily}',
                        'font-size':                    '${buttonSelectedLabelFontSize}',
                        'font-style':                   '${buttonSelectedLabelFontStyle}',
                        'font-weight':                  '${buttonSelectedLabelFontWeight}',
                        'line-height':                  '${buttonSelectedLabelLineSpacing}',
                        'letter-spacing':               '${buttonSelectedLabelLetterSpacing}',
                        'text-align':                   '${buttonSelectedLabelTextAlignment}',
                        'border-color':                 '${buttonSelectedLabelBorderColor}',
                        'border-width':                 '${buttonSelectedLabelBorderThickness}',
                        'border-style':                 '${buttonSelectedLabelBorderStyle}',
                        height:                         '32px',
                        float:                          'left',                        
                        position:                       'relative',
                        margin:                         '0 4px',
                        padding:                        '0px',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'white-space':                  'nowrap'
                    }
                }
            ]
        },
        */
        //Button Pressed
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_pres',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-backgroundcolor-pressed}',
                        'border-color':                 '${button-transparent-bordercolor-pressed}',
                        'border-width':                 '${button-transparent-borderthickness-pressed}',
                        'border-style':                 '${button-transparent-border-style-pressed}',
                        'border-radius':                '${button-transparent-radius-pressed}',
                        width:                          '${button-transparent-width}',
                        height:                         '${button-transparent-height}',
                        padding:                        '${button-transparent-padding}',
                        float:                          '${button-transparent-alignment}',
                        'line-height':                  '32px',
                        position:                       'relative',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'user-select':                  'none'
                    }
                }
            ]
        },
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_pres div.dhxtoolbar_text',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-text-backgroundcolor-pressed}',
                        color:                          '${button-transparent-text-color-pressed}',
                        'font-family':                  '${button-transparent-fontfamily-pressed}',
                        'font-size':                    '${button-transparent-fontsize-pressed}',
                        'font-style':                   '${font-style-cond(button-transparent-fontstyle-pressed)}',
                        'text-decoration':              '${text-decoration-cond(button-transparent-fontstyle-pressed)}',
                        'font-weight':                  '${button-transparent-fontweight-pressed}',
                        'line-height':                  '${buttonPressedLabelLineSpacing}',
                        'letter-spacing':               '${button-transparent-letterspacing}',
                        'text-align':                   '${button-transparent-text-alignment}',
                        'border-color':                 '${buttonPressedLabelBorderColor}',
                        'border-width':                 '${buttonPressedLabelBorderThickness}',
                        'border-style':                 '${buttonPressedLabelBorderStyle}',
                        height:                         '32px',
                        float:                          'left',                        
                        position:                       'relative',
                        margin:                         '0 4px',
                        padding:                        '0px',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'white-space':                  'nowrap'
                    }
                }
            ]
        },
        //Button Disabled
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_dis',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-backgroundcolor-disabled}',
                        'border-color':                 '${button-transparent-bordercolor-disabled}',
                        'border-width':                 '${button-transparent-borderthickness-disabled}',
                        'border-style':                 '${button-transparent-border-style-disabled}',
                        'border-radius':                '${button-transparent-radius-disabled}',
                        width:                          '${button-transparent-width}',
                        height:                         '${button-transparent-height}',
                        padding:                        '${button-transparent-padding}',
                        float:                          '${button-transparent-alignment}',
                        'line-height':                  '32px',
                        position:                       'relative',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'user-select':                  'none'
                    }
                }
            ]
        },
        {
            class:  '.toolbar-button-theming div.dhx_toolbar_btn.dhxtoolbar_btn_dis div.dhxtoolbar_text',
            states:
            [
                {
                    state:  '',
                    styles: {
                        background :                    '${button-transparent-text-backgroundcolor-disabled}',
                        color:                          '${button-transparent-text-color-disabled}',
                        'font-family':                  '${button-transparent-fontfamily-disabled}',
                        'font-size':                    '${button-transparent-fontsize-disabled}',
                        'font-style':                   '${font-style-cond(button-transparent-fontstyle-disabled)}',
                        'text-decoration':              '${text-decoration-cond(button-transparent-fontstyle-disabled)}',
                        'font-weight':                  '${button-transparent-fontweight-disabled}',
                        'line-height':                  '${buttonDisabledLabelLineSpacing}',
                        'letter-spacing':               '${button-transparent-letterspacing}',
                        'text-align':                   '${button-transparent-text-alignment}',
                        'border-color':                 '${buttonDisabledLabelBorderColor}',
                        'border-width':                 '${buttonDisabledLabelBorderThickness}',
                        'border-style':                 '${buttonDisabledLabelBorderStyle}',
                        height:                         '32px',
                        float:                          'left',                        
                        position:                       'relative',
                        margin:                         '0 4px',
                        padding:                        '0px',
                        cursor:                         'default',
                        overflow:                       'hidden',
                        'white-space':                  'nowrap'
                    }
                }
            ]
        }
    ];
};

TW.Runtime.Widgets.gridadvanced.getDefaultWidgetStyleFlat = function() {
    return {
        gridBackgroundColor             	        : 'transparent',
        'gridadv-bordercolor'                 		: '#D8DBDE',
        'gridadv-borderthickness'             		: '1px',
        'gridadv-header-label-fontfamily'           : 'helvetica, arial',
        'gridadv-header-label-fontsize'             : '11px',
        'gridadv-header-label-fontstyle'			: 'uppercase',
        'gridadv-header-label-fontweight'			: 'bold',
        'gridadv-header-label-fontcolor'			: '#6E717C',
        'gridadv-header-backgroundcolor'            : '#202020',
        'gridadv-header-divider-color'         		: '#FFFFFF',
        'gridadv-header-divider-thickness'     		: '1px',
        'gridadv-header-divider-style'         		: 'solid',
        'gridadv-row-backgroundcolor'              	: '#F5F5F5',
        rowInteriorLineColor            		    : '#333333',
        rowInteriorLineThickness        		    : '1px',
        rowInteriorLineStyle            		    : 'normal',
        'gridadv-row-backgroundcolor-alt'           : '#FFFFFF',
        alRowInteriorLineColor          		    : '#333333',
        alRowInteriorLineThickness      		    : '1px',
        alRowInteriorLineStyle          		    : 'normal',
        'gridadv-cell-backgroundcolor'             	: '',
        'gridadv-cell-bordercolor'           		: '#DDDDDD',
        'gridadv-cell-borderthickness'       		: '1px',
        'gridadv-cell-border-style'           		: 'solid',
        'gridadv-cell-text-fontfamily'              : 'Roboto, Arial, Helvetica',
        'gridadv-cell-text-fontsize'                : '11px',
        'gridadv-cell-text-fontstyle'               : 'normal',
        'gridadv-cell-text-fontweight'              : 'normal',
        'gridadv-cell-text-fontcolor'				: '#232B2D',
        'gridadv-cell-text-text-alignment'          : '',
        'gridadv-cell-bordercolor-hover'           		: '#DDDDDD',
        'gridadv-cell-borderthickness-hover'       		: '1px',
        'gridadv-cell-border-style-hover'           		: 'solid',
        'gridadv-cell-text-fontfamily-hover'              : 'Roboto, Arial, Helvetica',
        'gridadv-cell-text-fontsize-hover'                : '11px',
        'gridadv-cell-text-fontstyle-hover'               : 'normal',
        'gridadv-cell-text-fontweight-hover'              : 'normal',
        'gridadv-cell-text-fontcolor-hover'				: '#232B2D',
        'gridadv-cell-text-text-alignment-hover'          : '',
        'gridadv-cell-bordercolor-selected'           		: '#DDDDDD',
        'gridadv-cell-borderthickness-selected'       		: '1px',
        'gridadv-cell-border-style-selected'           		: 'solid',
        'gridadv-cell-text-fontfamily-selected'              : 'Roboto, Arial, Helvetica',
        'gridadv-cell-text-fontsize-selected'                : '11px',
        'gridadv-cell-text-fontstyle-selected'               : 'normal',
        'gridadv-cell-text-fontweight-selected'              : 'normal',
        'gridadv-cell-text-fontcolor-selected'				: '#232B2D',
        'gridadv-cell-text-text-alignment-selected'          : '',
        'gridadv-row-backgroundcolor-hover'			: '#F7F7F7',
        'gridadv-row-backgroundcolor-alt-hover'     : '#F7F7F7',
        'gridadv-row-backgroundcolor-selected'		: '#EAF6FF',
        'gridadv-row-backgroundcolor-alt-selected'  : '#EAF6FF',
        'toolbar-backgroundcolor'          		    : '#F7F7F7',
        'toolbar-bordercolor'              		    : '#DFDFDF',
        'toolbar-borderthickness'          		    : '1px',
        /*tooltip-backgroundcolor                   : '#E6E8EA',
        tooltip-bordercolor              		    : '#C2C7CE',
        tooltip-text-fontfamily               		: '',
        tooltip-text-color                		    : '#232B2D',
        tooltip-text-fontsize                 		: '',
        tooltip-text-fontstyle                		: '',
        tooltip-text-fontweight               		: '',
        tooltip-height                   		    : '',
        tooltip-width                    		    : '',
        tooltip-text-linespacing              		: '',
        tooltip-text-letterspacing            		: '',
        tooltip-box-shadow                		    : '0px 2px 4px 0px #000000',*/
        'textfield-field-text-color' 				: '#404040',        
        'textfield-field-fontfamily' 				: 'Roboto,Arial,Helvetica',        
        'textfield-field-fontsize' 					: '14px',        
        'textfield-field-fontstyle' 				: '',        
        'textfield-field-fontweight' 				: '',        
        'textfield-field-letterspacing' 			: '',        
        searchFieldLineSpacing 					    : 'normal',        
        'textfield-field-alignment' 				: '',        
        'textfield-field-borderthickness' 			: '1px',        
        'textfield-field-bordercolor' 				: '#DFDFDF',        
        'textfield-field-border-style' 				: 'solid',        
        'textfield-field-backgroundcolor' 			: '#FFFFFF',        
        'textfield-field-text-color-hover' 			: '#404040',        
        'textfield-field-fontfamily-hover' 			: 'Roboto,Arial,Helvetica',        
        'textfield-field-fontsize-hover' 			: '14px',        
        'textfield-field-fontstyle-hover' 			: '',        
        'textfield-field-fontweight-hover' 			: '',        
        hoverSearchFieldLetterSpacing 			    : '',        
        hoverSearchFieldLineSpacing 			    : 'normal',        
        hoverSearchFieldTextAlignment 			    : '',        
        'textfield-field-borderthickness-hover' 	: '1px',        
        'textfield-field-bordercolor-hover' 		: '#DFDFDF',        
        hoverSearchFieldBorderStyle 			    : 'solid',        
        'textfield-field-backgroundcolor-hover' 	: '#FFFFFF',        
        'textfield-field-text-color-pressed' 		: '#404040',        
        'textfield-field-fontfamily-pressed' 		: 'Roboto,Arial,Helvetica',        
        'textfield-field-fontsize-pressed' 			: '14px',        
        'textfield-field-fontstyle-pressed'			: '',        
        'textfield-field-fontweight-pressed' 		: '',        
        pressedSearchFieldLetterSpacing 		    : '',        
        pressedSearchFieldLineSpacing 			    : 'normal',        
        pressedSearchFieldTextAlignment 		    : '',        
        'textfield-field-borderthickness-pressed' 	: '1px',        
        'textfield-field-bordercolor-pressed' 		: '#DFDFDF',        
        pressedSearchFieldBorderStyle 			    : 'solid',        
        'textfield-field-backgroundcolor-pressed' 	: '#FFFFFF',        
        'textfield-field-text-color-disabled' 		: '#404040',        
        'textfield-field-fontfamily-disabled' 		: 'Roboto,Arial,Helvetica',        
        'textfield-field-fontsize-disabled' 		: '14px',        
        'textfield-field-fontstyle-disabled' 		: '',        
        'textfield-field-fontweight-disabled' 		: '',        
        disabledSearchFieldLetterSpacing		    : '',        
        disabledSearchFieldLineSpacing 			    : 'normal',        
        disabledSearchFieldTextAlignment		    : '',        
        'textfield-field-borderthickness-disabled' 	: '1px',        
        'textfield-field-bordercolor-disabled' 		: '#DFDFDF',        
        disabledSearchFieldBorderStyle 			    : 'solid',        
        'textfield-field-backgroundcolor-disabled'	: '#FFFFFF',
        'textfield-text-label-color'                : '#232B2D',
        'textfield-text-label-fontfamily'           : 'inherit',
        'textfield-text-label-fontsize'             : 'inherit',
        'textfield-text-label-fontstyle'            : 'inherit',
        'textfield-text-label-fontweight'           : 'inherit',        
        'label-letterspacing' 				        : '',        
        'label-linespacing' 					    : '32px',        
        'label-alignment' 				            : '',        
        'label-borderthickness' 					: '',        
        'label-bordercolor' 					    : '',        
        'label-border-style' 					    : '',        
        'label-backgroundcolor' 				    : '',        
        /*disabledSearchLabelFontColor 			    : '',        
        disabledSearchLabelFontFamily 			    : '',        
        disabledSearchLabelFontSize 			    : '',        
        disabledSearchLabelFontStyle 			    : '',        
        disabledSearchLabelFontWeight 			    : '',        
        disabledSearchLabelLetterSpacing		    : '',        
        disabledSearchLabelLineSpacing 			    : '',        
        disabledSearchLabelTextAlignment		    : '',        
        disabledSearchLabelBorderWidth 			    : '',        
        disabledSearchLabelBorderColor 			    : '',        
        disabledSearchLabelBorderStyle 			    : '',        
        disabledSearchLabelBackgroundColor          : '',*/
        //Button Active
        'button-transparent-backgroundcolor'            :'transparent',
        'button-transparent-bordercolor'                :'#fafafa',
        'button-transparent-borderthickness'            :'0 1px 0 1px',
        'button-transparent-border-style'               :'solid',
        'button-transparent-radius'                     :'0px',
        'button-transparent-width'                      :'',
        'button-transparent-height'                     :'34px',
        'button-transparent-padding'                    :'0 20px',
        'button-transparent-alignment'                  :'',
        'button-transparent-text-backgroundcolor'       :'inherit',
        'button-transparent-text-color'                 :'#6e717c',
        'button-transparent-fontfamily'                 :'inherit',
        'button-transparent-fontsize'                   :'inherit',
        'button-transparent-fontstyle'                  :'inherit',
        'button-transparent-fontweight'                 :'inherit',
        'button-transparent-linespacing'                :'32px',
        'button-transparent-letterspacing'              :'',
        'button-transparent-text-alignment'             :'center',
        'buttonActiveLabelBorderColor'              :'',
        'buttonActiveLabelBorderThickness'          :'',
        'buttonActiveLabelBorderStyle'              :'',

        //Button Hover
        'button-transparent-backgroundcolor-hover'      :'#236192',
        'button-transparent-bordercolor-hover'          :'#ebebeb',
        'button-transparent-borderthickness-hover'      :'0 1px 0 1px',
        'button-transparent-border-style-hover'         :'solid',
        'button-transparent-radius-hover'               :'0px',
        'buttonHoverWidth'                          :'',
        'buttonHoverHeight'                         :'34px',
        'buttonHoverPadding'                        :'0 20px',
        'buttonHoverAlignment'                      :'',
        'button-transparent-text-backgroundcolor-hover' :'inherit',
        'button-transparent-text-color-hover'           :'#FFFFFF',
        'button-transparent-fontfamily-hover'           :'inherit',
        'button-transparent-fontsize-hover'             :'inherit',
        'button-transparent-fontstyle-hover'            :'inherit',
        'button-transparent-fontweight-hover'           :'inherit',
        'buttonHoverLabelLineSpacing'               :'32px',
        'buttonHoverLabelLetterSpacing'             :'',
        'buttonHoverLabelTextAlignment'             :'center',
        'buttonHoverLabelBorderColor'               :'',
        'buttonHoverLabelBorderThickness'           :'',
        'buttonHoverLabelBorderStyle'               :'',

    //Button Selected
    // buttonSelectedBackgroundColor:          '#0094C8',
    // buttonSelectedBorderColor:              '',
    // buttonSelectedBorderThickness:          '',
    // buttonSelectedBorderStyle:              '',
    // buttonSelectedBorderRadius:             '',
    // buttonSelectedWidth:                    '',
    // buttonSelectedHeight:                   '',
    // buttonSelectedPadding:                  '',
    // buttonSelectedAlignment:                '',
    // buttonSelectedLabelBackgroundColor:     '',
    // buttonSelectedLabelFontColor:           '#FFFFFF',
    // buttonSelectedLabelFontFamily:          '',
    // buttonSelectedLabelFontSize:            '',
    // buttonSelectedLabelFontStyle:           '',
    // buttonSelectedLabelFontWeight:          '',
    // buttonSelectedLabelLineSpacing:         '',
    // buttonSelectedLabelLetterSpacing:       '',
    // buttonSelectedLabelTextAlignment:       '',
    // buttonSelectedLabelBorderColor:         '',
    // buttonSelectedLabelBorderThickness:     '',
    // buttonSelectedLabelBorderStyle:         '',

        //Button Pressed
        'button-transparent-backgroundcolor-pressed'    :'#005878',
        'button-transparent-bordercolor-pressed'        :'#d2d2d2',
        'button-transparent-borderthickness-pressed'    :'0 1px 0 1px',
        'button-transparent-border-style-pressed'       :'solid',
        'button-transparent-radius-pressed'             :'0px',
        'buttonPressedWidth'                        :'',
        'buttonPressedHeight'                       :'34px',
        'buttonPressedPadding'                      :'0 20px',
        'buttonPressedAlignment'                    :'',
        'button-transparent-text-backgroundcolor-pressed' :'inherit',
        'button-transparent-text-color-pressed'         :'#FFFFFF',
        'button-transparent-fontfamily-pressed'         :'inherit',
        'button-transparent-fontsize-pressed'           :'inherit',
        'button-transparent-fontstyle-pressed'          :'inherit',
        'button-transparent-fontweight-pressed'         :'inherit',
        'buttonPressedLabelLineSpacing'             :'32px',
        'buttonPressedLabelLetterSpacing'           :'',
        'buttonPressedLabelTextAlignment'           :'center',
        'buttonPressedLabelBorderColor'             :'',
        'buttonPressedLabelBorderThickness'         :'',
        'buttonPressedLabelBorderStyle'             :'',

        //Button Disabled
        'button-transparent-backgroundcolor-disabled'   :'transparent',
        'button-transparent-bordercolor-disabled'       :'#fafafa',
        'button-transparent-borderthickness-disabled'   :'0px',
        'button-transparent-border-style-disabled'                 :'solid',
        'button-transparent-radius-disabled'            :'0px',
        'buttonDisabledWidth'                       :'',
        'buttonDisabledHeight'                      :'34px',
        'buttonDisabledPadding'                     :'0 20px',
        'buttonDisabledAlignment'                   :'',
        'button-transparent-text-backgroundcolor-disabled':'inherit',
        'button-transparent-text-color-disabled'        :'#adb5bd',
        'button-transparent-fontfamily-disabled'        :'inherit',
        'button-transparent-fontsize-disabled'          :'inherit',
        'button-transparent-fontstyle-disabled'         :'inherit',
        'button-transparent-fontweight-disabled'        :'inherit',
        'buttonDisabledLabelLineSpacing'            :'32px',
        'buttonDisabledLabelLetterSpacing'          :'',
        'buttonDisabledLabelTextAlignment'          :'center',
        'buttonDisabledLabelBorderColor'            :'',
        'buttonDisabledLabelBorderThickness'        :'',
        'buttonDisabledLabelBorderStyle'            :''
    };
};
