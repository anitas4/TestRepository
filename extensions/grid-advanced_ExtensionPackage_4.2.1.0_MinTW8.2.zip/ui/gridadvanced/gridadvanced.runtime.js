gaRequire.require.config({
    baseUrl: '../Common/extensions/grid-advanced_ExtensionPackage/ui/gridadvanced/include',
    waitSeconds: 30
});

TW.Runtime.Widgets.gridadvanced = function () {

    var thisWidget = this;
    var gridAdvanced;
    var tableData = [];
    var defaultStyles = {};
    var gridId;
    var gridHeaderColAlign = [];
    var containerWidth = 0;
    var currentUser;
    var updatedProperties = {};
    var propertyUpdateOrder = [];
    var checkBound;
    var configLoaded = false;
    var tableSized = false;
    var infoTableDataShape;
    var dataShapeInfo = {};

    this.runtimeProperties = function () {
        return {
            'needsDataLoadingAndError': true,
            'supportsAutoResize': true
        };
    };

    this.resize = function () {
        // If the container for the table has been made visible we need to resize the columns
        if(this.properties.ResponsiveLayout) {
            var widgetObj = this;

            clearTimeout(this.resizeHandle);
            this.resizeHandle = setTimeout(function() {
                if (gridAdvanced) {
                    gridAdvanced.resize();
                }
                // Now that the columns have been resized we can reset the height and show the grid
                widgetObj.jqElement.height("auto");
                tableSized = true;
            }, 50);
        }
    };

    this.renderHtml = function () {
        gridId = thisWidget.jqElementId + '-grid-advanced';
        var responsiveStyle = "";
        TW.Session.UpdateCurrentUser(function() {
            currentUser = TW.Session.CurrentUser;
        });
        if(this.properties.ResponsiveLayout)
        {
        	responsiveStyle = ' style="width: 100%; height: 100%" ';
        }
        var html = '<div class="widget-content widget-gridadvanced">' +
            '<div id="' + gridId + '-top-container" class="grid-control-container top-container"></div>' +
            '<div id="' + gridId + '-bottom-container" class="grid-control-container bottom-container"></div>' +
            '<div id="' + gridId + '" ' + responsiveStyle + '></div></div>';
        return html;
    };

    this.updateProperty = function (updatePropertyInfo) {
        switch (updatePropertyInfo.TargetProperty) {
            case 'StyleProperties':
                if (this.setStyleProperties) {
                    this.setStyleProperties(updatePropertyInfo.RawDataFromInvoke, 'widget-gridadvanced');
                }
                break;
            case 'Configuration' :
                try {
                    if (typeof updatePropertyInfo.SinglePropertyValue === 'string') {
                        JSON.parse(updatePropertyInfo.SinglePropertyValue);
                    }
                } catch (e) {
                    TW.Runtime.showStatusText('error', 'Invalid configuration - Unable to parse into JSON');
                    return;
                }
                updatedProperties[updatePropertyInfo.TargetProperty] = updatePropertyInfo.SinglePropertyValue;
                break;
            case 'Data' :
                dataShapeInfo.changed = false;
                dataShapeInfo.empty = false;
                dataShapeInfo.keys = _.keys(updatePropertyInfo.DataShape);
                updatedProperties[updatePropertyInfo.TargetProperty] = updatePropertyInfo.ActualDataRows;
                if(!_.isEqual(infoTableDataShape,updatePropertyInfo.DataShape)) {
                    infoTableDataShape = updatePropertyInfo.DataShape;
                    dataShapeInfo.changed = true;
                }
                if(_.isEmpty(updatePropertyInfo.DataShape)){
                    dataShapeInfo.empty = true;
                }
                break;
            case 'SelectedRows':
                updatedProperties[updatePropertyInfo.TargetProperty] = updatePropertyInfo.ActualDataRows;
                break;
            case 'SelectRow':
                updatedProperties[updatePropertyInfo.TargetProperty] = updatePropertyInfo.SinglePropertyValue;
                break;
            case 'ExpandRow':
                updatedProperties[updatePropertyInfo.TargetProperty] = updatePropertyInfo.SinglePropertyValue;
                break;
            case 'DefaultSelectedRows' :
                updatedProperties[updatePropertyInfo.TargetProperty] = updatePropertyInfo.SinglePropertyValue;
                break;
            case 'QueryFilter' :
                updatedProperties[updatePropertyInfo.TargetProperty] = updatePropertyInfo.ActualDataRows[0].Query;
                break;
            case 'IsEditable' :
                updatedProperties[updatePropertyInfo.TargetProperty] = updatePropertyInfo.RawSinglePropertyValue;
                break;
            case 'FooterData' :
                updatedProperties[updatePropertyInfo.TargetProperty] = updatePropertyInfo.ActualDataRows;
                break;
        }
        propertyUpdateOrder.push(updatePropertyInfo.TargetProperty);
        var bound = this.isConfigurationBound();
        if (this.checkBindables(bound)) {
            this.updateBindables(bound);
        }
    };

    this.isConfigurationBound = function() {
        var configurationBound = false;
        if (thisWidget.mashup.DataBindings && thisWidget.mashup.DataBindings.length > 0) {
            var bindings = thisWidget.mashup.DataBindings;
            bindings.forEach(function(binding) {
                if (binding.PropertyMaps && binding.PropertyMaps.length > 0) {
                    if (binding.PropertyMaps[0].TargetProperty === 'Configuration'
                        && binding.TargetId === thisWidget.idOfThisElement) {
                        configurationBound = true;
                    }
                }
            });
        }
        return configurationBound;
    };

    this.checkBindables = function(configurationBound) {
        if ((gridAdvanced && configurationBound === true && updatedProperties['Configuration'])
            || (gridAdvanced && updatedProperties['Data'])
            || (gridAdvanced && updatedProperties['SelectedRows'])
            || (gridAdvanced && updatedProperties['SelectedRow'])
            || (gridAdvanced && updatedProperties['ExpandRow'])
            || (gridAdvanced && updatedProperties['DefaultSelectedRows'])
            || (gridAdvanced && updatedProperties['IsEditable'] !== undefined)
            || (gridAdvanced && updatedProperties['FooterData'])
            || (gridAdvanced && updatedProperties.hasOwnProperty('QueryFilter'))) {
            return true;
        } else {
            return false;
        }
    };

    this.updateBindables = function(configurationBound) {
        if (checkBound) {
            clearTimeout(checkBound);
        }
        propertyUpdateOrder.forEach(function (property) {
            var propertyData = updatedProperties[property];
            if (property === 'Configuration') {
                var _cnf;
                try {
                    _cnf = JSON.parse(propertyData);
                } catch(e){
                    TW.Runtime.showStatusText('error', 'Invalid configuration - Unable to parse into JSON');
                    return;
                }
                var parser = thisWidget.ConfigurationParserFactory.createParser('dynamic', _cnf);
                gridAdvanced.updateBindable('Configuration', parser.configuration);
                configLoaded = true;
            }
            else if (property === 'Data') {
                gridAdvanced.updateBindable('Data', propertyData, dataShapeInfo);
            }
            else if (property === 'SelectedRows') {
                gridAdvanced.updateBindable('SelectedRows', propertyData);
            }
            else if (property === 'SelectedRow') {
                gridAdvanced.updateBindable('SelectedRow', propertyData);
            }
            else if (property === 'ExpandRow') {
                gridAdvanced.updateBindable('ExpandRow', propertyData);
            }
            else if (property === 'DefaultSelectedRows') {
                gridAdvanced.updateBindable('DefaultSelectedRows', propertyData);
            }
            else if (property === 'QueryFilter') {
                gridAdvanced.updateBindable('QueryFilter', propertyData);
            }
            else if (property === 'IsEditable') {
                gridAdvanced.updateBindable('IsEditable', propertyData);
            }
            else if (property === 'FooterData') {
                gridAdvanced.updateBindable('FooterData', propertyData);
            }
        });
        this.positionContainers();
        gridAdvanced.onRowDblClicked = thisWidget.onRowDblClicked;
        updatedProperties = {};
        propertyUpdateOrder = [];
    };

    this.afterRender = function () {
        gaRequire.define("jquery", function () {
            //drop the `true` if you want jQuery (but not $) to remain global
            return $;
        });
        gaRequire.require(["grid-advanced-widget", "dhtmlx-bundle"], function() {
            gaRequire.requirejs(['jquery',
                    'tw-grid-advanced/grid-advanced/tw-grid-advanced',
                    'tw-grid-advanced/grid-advanced/configuration-parser-factory',
                    'tw-grid-advanced/grid-advanced/tooltip/tooltip-factory',
                    'dhxgrid'
                ],
                function() {
                    thisWidget.TwGridAdvanced = arguments[1].TwGridAdvanced;
                    thisWidget.ConfigurationParserFactory = arguments[2].ConfigurationParserFactory;
                    gridAdvanced = new thisWidget.TwGridAdvanced(thisWidget, gridId, thisWidget.rowSelectionCallback);
                    gridAdvanced.queryDataServiceInvoker = thisWidget.createServiceInvoker(
                        thisWidget.getProperty('DataServiceBindingDef'),
                        undefined
                    );
                    gridAdvanced.imagePath = '../Common/extensions/grid-advanced_ExtensionPackage/ui/gridadvanced/imgs/';
                    gridAdvanced.menuIconsPath = '../Common/extensions/grid-advanced_ExtensionPackage/ui/gridadvanced/common/images/';
                    gridAdvanced.structPath = '../Common/extensions/grid-advanced_ExtensionPackage/ui/gridadvanced/common/';
                    gridAdvanced.tooltip = arguments[3].TooltipFactory.getTooltip('mashup-builder');
                    containerWidth = thisWidget.jqElement.width();
                    if (containerWidth === 0 && !tableSized) {
                        thisWidget.jqElement.height(0);
                    }
                    if (thisWidget.properties.ResponsiveLayout) {
                        gridAdvanced.enableResponsiveLayout();
                    }
                    gridAdvanced.enableUserConfiguration(currentUser, thisWidget.getProperty('ConfigurationId'),
                        thisWidget.getProperty('CookiePersistence'));
                    gridAdvanced.statusTextMessageCallback = TW.Runtime.showStatusText;
                    gridAdvanced.cellEditCallback = thisWidget.handleCellEditsCallback;
                    gridAdvanced.gridEditCallback = thisWidget.handleGridEditsCallback;
                    gridAdvanced.rowsDeletedCallback = thisWidget.handleRowsDeletedCallback;
                    gridAdvanced.enableFilterEventOnConfigChange = thisWidget.getProperty('EnableFilterEventOnConfigChange');
                    thisWidget.attachEvents();
                    let configurationFromJson = thisWidget.getProperty('Configuration');
                    if (typeof configurationFromJson === 'string' && configurationFromJson !== '') {
                        try {
                            configurationFromJson = JSON.parse(configurationFromJson);
                        } catch (e) {
                            TW.Runtime.showStatusText('error', 'Invalid configuration - Unable to parse into JSON');
                            return;
                        }
                        
                    }
                    if (configurationFromJson && Object.keys(configurationFromJson).length > 0) {
                        var parser = thisWidget.ConfigurationParserFactory.createParser('dynamic', configurationFromJson);
                        gridAdvanced.updateBindable('Configuration', parser.configuration);
                    } else if(!thisWidget.isConfigurationBound()) {
	                    var parser = thisWidget.ConfigurationParserFactory.createParser('mashup-builder', thisWidget,
                                                                                        TW.getStyleFromStyleDefinition,
                                                                                        TW.Runtime.convertLocalizableString);
	                    gridAdvanced.updateBindable('Configuration', parser.configuration);
                    }
                    gridAdvanced.localizationUtil = function(token) {
                        var val = TW.Runtime.convertLocalizableString(Encoder.htmlEncode(token)).replace(/,/g,'&#44;');
                        return val;
                    };
                    gridAdvanced.l8nTokens = {
                        search: TW.Runtime.convertLocalizableString("[[search]]", "Search"),
                        reset: TW.Runtime.convertLocalizableString("[[reset]]", "Reset"),
                        edit: TW.Runtime.convertLocalizableString("[[edit]]", "Edit"),
                        save: TW.Runtime.convertLocalizableString("[[save]]", "Save"),
                        cancel: TW.Runtime.convertLocalizableString("[[cancel]]", "Cancel"),
                        add: TW.Runtime.convertLocalizableString("[[add]]", "Add"),
                        delete: TW.Runtime.convertLocalizableString("[[delete]]", "Delete"),
                        results: TW.Runtime.convertLocalizableString("[[results]]", "Results"),
                        records: TW.Runtime.convertLocalizableString("[[records]]", "Rows"),
                        to: ' - ',
                        page: TW.Runtime.convertLocalizableString("[[page]]", "Page"),
                        perpage: TW.Runtime.convertLocalizableString("[[perpage]]", "rows per page"),
                        first: TW.Runtime.convertLocalizableString("[[toFirstPage]]", "To first Page"),
                        previous: TW.Runtime.convertLocalizableString("[[prevPage]]", "Previous Page"),
                        found: TW.Runtime.convertLocalizableString("[[foundRecords]]", "Found records"),
                        next: TW.Runtime.convertLocalizableString("[[nextPage]]", "Next Page"),
                        last: TW.Runtime.convertLocalizableString("[[toLastPage]]", "To last Page"),
                        of: TW.Runtime.convertLocalizableString("[[spacedOf]]", " of "),
                        notfound: TW.Runtime.convertLocalizableString("[[notFound]]", "No Records Found"),
                        maxRowsWarning1: TW.Runtime.convertLocalizableString("[[maxRowsWarning1]]", "The maximum grid cache size of "),
                        maxRowsWarning2: TW.Runtime.convertLocalizableString("[[maxRowsWarning2]]", " rows has been reached. "),
                        maxRowsWarning3: TW.Runtime.convertLocalizableString("[[maxRowsWarning3]]", "Please refresh your browser or close some nodes to free up memory. "),
                        freeMemoryWarning: TW.Runtime.convertLocalizableString("[[freeMemoryWarning]]", "Please wait while we clear the row cache to free up memory, this may take a minute..."),
                    };

                    var bound = thisWidget.isConfigurationBound();
                    if (thisWidget.checkBindables(bound)) {
                        thisWidget.updateBindables(bound);
                    }
                });
            if (thisWidget.applyTheme) {
                thisWidget.applyTheme('widget-gridadvanced');
            }
        });
    };

    this.attachEvents = function() {
        $('#' + gridId).on('queryGridColumns', function(event, query) {
        	thisWidget.setProperty('QueryFilter', query);
        	thisWidget.jqElement.triggerHandler('Filter');
        });
    };

    this.onRowDblClicked = function(){
        thisWidget.jqElement.triggerHandler('DoubleClicked');
    };

    this.rowSelectionCallback = function(rowIndexes, rows){
        var clonedTable = TW.InfoTableUtilities.CloneInfoTable({ "dataShape" : { "fieldDefinitions" : infoTableDataShape}, "rows" : rows });

        thisWidget.setProperty('SelectedRows', clonedTable);
        thisWidget.jqElement.triggerHandler('SelectedRowsChanged');
        setTimeout(function() {
            thisWidget.updateSelection('Data', rowIndexes);
        },1);
    };

    this.handleCellEditsCallback = function(stage, rows) {
        if (stage === 0) {
            thisWidget.jqElement.triggerHandler('EditCellStarted');
        }
        else if (stage === 2) {
            var editedRowsInfoTable = { "dataShape" : { "fieldDefinitions" : infoTableDataShape}, "rows" : rows };
            thisWidget.setProperty('EditedTable', editedRowsInfoTable);
            thisWidget.jqElement.triggerHandler('EditCellCompleted');
        }
    };

    this.handleGridEditsCallback = function(stage) {
        if (stage === 0) {
            thisWidget.jqElement.triggerHandler('EditStarted'); 
            //Before every edit, the stale records should be removed from EditedTable and DeletedTable
            var editedRowsInfoTable = { 'dataShape' : { 'fieldDefinitions' : ''}, 'rows' : [] };
            thisWidget.setProperty('EditedTable', editedRowsInfoTable);
            var deletedRowsInfoTable = { dataShape : { fieldDefinitions : ''}, rows : [], name : 'InfoTable' };
            thisWidget.setProperty('DeletedTable', deletedRowsInfoTable);
        } else if (stage === 1) {
            thisWidget.jqElement.triggerHandler('EditCompleted');
        } else if (stage === 2) {
            thisWidget.jqElement.triggerHandler('EditCancelled');
        } else if (stage === 3){
            //Empty records from EditedTable while deleting
            if(thisWidget.getProperty('EditedTable').rows.length > 0){
                TW.log.info('Grid edit is not supported while deleting the rows. The edited cell values will be ignored here.');
                var editedRowsInfoTable = { 'dataShape' : { 'fieldDefinitions' : ''}, 'rows' : [] };
                thisWidget.setProperty('EditedTable', editedRowsInfoTable);
            }
            
        }
    };

    this.handleRowsDeletedCallback = function(rows) {
        var deletedRowsInfoTable = { dataShape : { fieldDefinitions : infoTableDataShape}, rows : rows, name : "InfoTable" };
        thisWidget.setProperty('DeletedTable', deletedRowsInfoTable);
    };


    /**
     * Place the pagination container either above or below the grid depending on the 'pageLocation' setting.
     * @param pageLocation
     */
    this.positionContainers = function(){
        var topId = '#' + gridId + '-top-container';
        var $top = $(topId).detach();

        var bottomId = '#' + gridId + '-bottom-container';
        var $bottom = $(bottomId).detach();

        $top.insertBefore('#'+gridId);
        $bottom.insertAfter('#'+gridId);
    };

    this.beforeDestroy = function () {
        // gridAdvanced.destroy();
        $("#tiptip_holder").css('display', 'none');
        // As tooltip creation have timeout of 300ms setting up a function with timeout 
        // to destroy tooltip in faster browser as a fail safe mechanism
        setTimeout(function() {
            $('#tiptip_holder').css('display', 'none');
        }, 305);
        gridAdvanced = undefined;
        thisWidget.PaginationSettings = undefined;
        thisWidget = undefined;
    };

    // callback from runtime to tell us that the selection has been changed by another widget
    this.handleSelectionUpdate = function (propertyName, selectedRows, newSelectedRowIndices) {
        gridAdvanced.selectRows(selectedRows, newSelectedRowIndices, true);
    };

    /**
     * Hits a service and calls the callback when done.
     * @param {*} bindingDef object containing the binding definitions for entityType, entityName and target, e.g. service name
     * @param {I} parameters additional query parameters
     */
    this.createServiceInvoker = function(serviceBindingDef, parameters) {
        var bindingDef = serviceBindingDef;
        if (bindingDef) {
            var invokeInfo =
            {
                entityType:     bindingDef.entityType,
                entityName:     bindingDef.entityName,
                characteristic: 'Services',
                target:         bindingDef.target,
                apiMethod:      RESTAPIConstants.Methods.METHOD_POST,
                parameters:     parameters

            };
            return new ThingworxInvoker(invokeInfo);
        }
    };
};